export const environment = {
  production: true,
  firebaseConfig:{
    apiKey: "AIzaSyBaBfAcX4CjhUBrY6U7KZEgQubvJAlmxtA",
    authDomain: "angular-anabel-88ec2.firebaseapp.com",
    databaseURL: "https://angular-anabel-88ec2-default-rtdb.europe-west1.firebasedatabase.app/",
    projectId: "angular-anabel-88ec2",
    storageBucket: "angular-anabel-88ec2.appspot.com",
    messagingSenderId: "254736320419",
    appId: "1:254736320419:web:214796ef9716c5d514bc16"
  }
};
