// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyBaBfAcX4CjhUBrY6U7KZEgQubvJAlmxtA",
    authDomain: "angular-anabel-88ec2.firebaseapp.com",
    databaseURL: "https://angular-anabel-88ec2-default-rtdb.europe-west1.firebasedatabase.app/",
    projectId: "angular-anabel-88ec2",
    storageBucket: "angular-anabel-88ec2.appspot.com",
    messagingSenderId: "254736320419",
    appId: "1:254736320419:web:214796ef9716c5d514bc16"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
