import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private angularFireAuth: AngularFireAuth) { }

  login(email: string, pw: string): Promise<any>{
    return this.angularFireAuth.signInWithEmailAndPassword(email, pw);
  }

  registro(email: string, pw: string): Promise<any>{
    return this.angularFireAuth.createUserWithEmailAndPassword(email, pw);
  }

  logout(): Promise<any>{
    return this.angularFireAuth.signOut();
  }

  comprobar(): Observable<any>{
    return this.angularFireAuth.authState;
  }
}
