import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-c3',
  templateUrl: './c3.component.html',
  styleUrls: ['./c3.component.css']
})
export class C3Component implements OnInit {

  hotel: string = '';
  entrada: string = '';
  salida: string = '';
  personas: number = 0;

  constructor(private ruta: ActivatedRoute) { 
    // Recuperar el parametro de la ruta
    console.log(ruta);
    this.hotel = this.ruta.snapshot.params['hotel'];

    // Recuperar los parametros recibidos como query params
    this.entrada = this.ruta.snapshot.queryParams['entrada'];
    this.salida = this.ruta.snapshot.queryParams['salida'];
    this.personas = this.ruta.snapshot.queryParams['personas'];
  }

  ngOnInit(): void {
  }

}
