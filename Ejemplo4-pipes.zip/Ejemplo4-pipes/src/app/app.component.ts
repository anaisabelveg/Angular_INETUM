import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  texto: string = "Bienvenidos al curso de Angular";
  numero: number = 9876443468.43245672348;

  // La fecha funciona de estas formas pero siempre mes/dia/año
  fecha: Date = new Date();  // fecha y hora actual del sistema
  //fecha: Date = new Date('12/25/2022');
  //fecha: string = '12/25/2022';

  porcentaje: number = 0.54898643;

  persona: any = {nombre: 'Pepito', apellido: 'Perez', edad: 38,
      telefonos:{tel1: 914568912, tel2: 616123456} };
}
