import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // linea

  /*
    comentario de bloque
  */

  nombre: string = 'Anabel';
  apellido: string = 'Vegas';

  deshabilitado: boolean = true;

  nombreTxt:string = '';

  fondo: string ='fondo';

  alumnos: any = [
    {repetidor: false, nombre: 'Juan', apellido: 'Lopez', nota: 7.5},
    {repetidor: false, nombre: 'Maria', apellido: 'Sanchez', nota: 5.8},
    {repetidor: true, nombre: 'Pedro', apellido: 'Pascal', nota: 3.2},
    {repetidor: true, nombre: 'Luis', apellido: 'Rodriguez', nota: 6.4},
    {repetidor: false, nombre: 'Laura', apellido: 'Arias', nota: 4.1},
    {repetidor: false, nombre: 'Jorge', apellido: 'Sanz', nota: 8.3}
  ];

  constructor(){
    // Crear un temporizador que transcurridos 3 segundos habilite el boton
    setTimeout( () => {
      this.deshabilitado = false;
    } , 3000);
  }

  saludar(): void{
    alert("Bienvenidos al curso de Angular");
  }
  
}
