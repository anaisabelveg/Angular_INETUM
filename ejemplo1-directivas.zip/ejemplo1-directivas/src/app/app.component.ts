import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // linea

  /*
    comentario de bloque
  */

  nombre: string = 'Anabel';
  apellido: string = 'Vegas';

  deshabilitado: boolean = true;

  nombreTxt:string = '';

  estiloFondo: string ='fondo';

  alumnos: any = [
    {valoracion: 'alta', repetidor: false, nombre: 'Juan', apellido: 'Lopez', nota: 7.5},
    {valoracion: 'media', repetidor: false, nombre: 'Maria', apellido: 'Sanchez', nota: 5.8},
    {valoracion: 'baja', repetidor: true, nombre: 'Pedro', apellido: 'Pascal', nota: 3.2},
    {valoracion: 'media', repetidor: true, nombre: 'Luis', apellido: 'Rodriguez', nota: 6.4},
    {valoracion: 'baja', repetidor: false, nombre: 'Laura', apellido: 'Arias', nota: 4.1},
    {valoracion: 'altaaaaaaa', repetidor: false, nombre: 'Jorge', apellido: 'Sanz', nota: 8.3}
  ];

  constructor(){
    // Crear un temporizador que transcurridos 3 segundos habilite el boton
    setTimeout( () => {
      this.deshabilitado = false;
    } , 3000);
  }

  saludar(): void{
    alert("Bienvenidos al curso de Angular");
  }
  
}
