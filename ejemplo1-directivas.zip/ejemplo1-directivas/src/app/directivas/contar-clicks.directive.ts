import { Directive, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appContarClicks]'
})
export class ContarClicksDirective {

  numeroClicks: number = 0;

  constructor() { }

  @HostBinding('style.font-size')
  size: string = '';

  @HostBinding('style.opacity')
  opacidad: number = 0.1;

  @HostListener('click')
  onClick(){
      this.numeroClicks++;
      this.size = (20 + this.numeroClicks + 'px');
      this.opacidad += 0.1;
  }

}
