import { Directive, ElementRef, Input, OnInit, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appNota]'
})
export class NotaDirective implements OnInit{

  @Input('appNota')
  alum: any;

  // En el constructor inyecto los recursos que voy a necesitar
  constructor(private renderer: Renderer2, private elRef: ElementRef) { }

  ngOnInit(): void {
      if (this.alum.nota >= 5){
        this.renderer.setProperty(this.elRef.nativeElement, "innerHTML",
          `${this.alum.nombre}  ${this.alum.apellido}: ${this.alum.nota} - APROBADO `);
      } else {
        this.renderer.setProperty(this.elRef.nativeElement, "innerHTML",
          `${this.alum.nombre}  ${this.alum.apellido}: ${this.alum.nota} - SUSPENSO `);
      }
  }

}
