import { Component } from '@angular/core';
import { PokemonService } from './services/pokemon.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  pokemons: any[] = [];
  next: string = '';
  previous: string = '';
  deshabilitado: boolean = true;
  nombre: string = '';
  pokemon: any;

  constructor(private pokemonService: PokemonService){

      // Esto no se puede hacer
      // this.pokemons = pokemonService.getAll();

      // Me subscribo al Observable para estar atenta a recibir las notificaciones
      pokemonService.getAll().subscribe( (datos) => {
        console.log(datos);
        this.pokemons = datos.results;
        this.next = datos.next;
      } );
  }

  buscar(){
    this.pokemonService.buscarPokemon(this.nombre).subscribe((item) => {
      console.log(item);
      this.pokemon = item;
    });
  }

  siguientes(){
    this.pokemonService.emitirPeticion(this.next).subscribe( (datos) => {
      console.log(datos);
      this.pokemons = datos.results;
      this.next = datos.next;
      this.previous = datos.previous;
      this.deshabilitado = false;
    } );
  }

  anteriores(){
    this.pokemonService.emitirPeticion(this.previous).subscribe( (datos) => {
      console.log(datos);
      this.pokemons = datos.results;
      this.next = datos.next;
      this.previous = datos.previous;
      if (this.previous == null){
        this.deshabilitado = true;
      }
    } );
  }
}
