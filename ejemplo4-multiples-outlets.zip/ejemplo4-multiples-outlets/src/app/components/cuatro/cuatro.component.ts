import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cuatro',
  templateUrl: './cuatro.component.html',
  styleUrls: ['./cuatro.component.css']
})
export class CuatroComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
