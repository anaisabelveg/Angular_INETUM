import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EquipoService {

  url: string = 'https://rickandmortyapi.com/api/character';
  cabeceras: HttpHeaders = new HttpHeaders( {"Content-type":"application/json"} );

  constructor(private http: HttpClient) { }

  getAll(): Observable<any>{
    return this.http.get(this.url, {headers: this.cabeceras});
  }
}
