import { Component, OnInit } from '@angular/core';
import { EquipoService } from 'src/app/services/equipo.service';

@Component({
  selector: 'app-equipo',
  templateUrl: './equipo.component.html',
  styleUrls: ['./equipo.component.css']
})
export class EquipoComponent implements OnInit {

  miEquipo: any[] = [];

  constructor(private equipoService: EquipoService) {
    equipoService.getAll().subscribe( (datos) => {
      console.log(datos);
      this.miEquipo = datos.results;
    } );
  }

  ngOnInit(): void {
  }

}
