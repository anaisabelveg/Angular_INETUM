import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Museo } from 'src/app/models/museo';
import { MuseosService } from 'src/app/services/museos.service';

@Component({
  selector: 'app-museos',
  templateUrl: './museos.component.html',
  styleUrls: ['./museos.component.css']
})
export class MuseosComponent implements AfterViewInit {

  museos: Museo[] = [];
  dataSource: any;
  nombreColumnas = ['nombre', 'abierto', 'horario', 'precio'];

  @ViewChild(MatSort)
  sort: MatSort | undefined;

  constructor(private museosService: MuseosService) {
    this.museos = this.museosService.getAll();
    this.dataSource = new MatTableDataSource(this.museos);
   }

  ngAfterViewInit(): void {
    // Inicializar el sort
    if (this.sort != undefined){
      this.dataSource.sort = this.sort;
    }
  }

}
